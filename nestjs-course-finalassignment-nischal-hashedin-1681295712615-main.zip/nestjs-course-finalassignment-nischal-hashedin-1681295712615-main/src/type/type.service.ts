import { Injectable } from "@nestjs/common";
import { Type } from "@prisma/client";
import { PrismaService } from "src/prisma/prisma.service";

@Injectable()
export class TypeService{
    constructor( private prisma: PrismaService){}
    async fetchAllTypes():Promise<Type[]>{
        return await this.prisma.type.findMany();
    }
}