import { Module } from "@nestjs/common";
import { TypeService } from "./type.service";
import { PrismaService } from "src/prisma/prisma.service";
import { JwtService } from "@nestjs/jwt";
import { TypeController } from "./type.controller";

@Module({
    providers: [TypeService, PrismaService, JwtService],
    exports: [TypeService],
    controllers: [TypeController]
})

export class TypeModule{}