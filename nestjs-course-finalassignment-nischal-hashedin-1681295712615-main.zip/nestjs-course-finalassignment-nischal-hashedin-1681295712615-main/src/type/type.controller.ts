import { Controller, Get } from "@nestjs/common";
import { ApiTags } from "@nestjs/swagger";
import { TypeService } from "./type.service";
import { Type } from "@prisma/client";

@ApiTags("type")
@Controller("types")
export class TypeController{
    constructor(private readonly typeService: TypeService){}

    @Get()
    async fetchAllTypes(): Promise<Type[]>{
        return this.typeService.fetchAllTypes();
    }
}