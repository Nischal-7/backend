import { Controller, Request, Post, UseGuards, Get } from "@nestjs/common";

@Controller()
export class AppController {
  
  constructor() {}


  @Get("environment")
  async checkEnvirontment(): Promise<String>{
    return process.env.APP_ENV || 'local'
  }
}
