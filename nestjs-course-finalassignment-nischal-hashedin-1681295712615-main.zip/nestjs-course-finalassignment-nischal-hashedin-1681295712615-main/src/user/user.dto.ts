import { ApiProperty } from "@nestjs/swagger";
import { IsEmail, IsNotEmpty, IsNumber } from "class-validator";

export class CreateUserDTO {
    @ApiProperty()
    first_name: string;
    @ApiProperty()
    last_name: string;
    @ApiProperty()
    role: string;
    @ApiProperty()
    @IsEmail()
    email: string;
    @ApiProperty()
    @IsNotEmpty()
    password: string;
    teamId?: number;
}

export class UpdateUserPasswordDTO {
    @ApiProperty()
    @IsEmail()
    email: string;
    @ApiProperty()
    @IsNotEmpty()
    oldPassword: string;
    @ApiProperty()
    @IsNotEmpty()
    newPassword: string;
}

export class UpdateUserTeamIdDTO{
    @ApiProperty()
    @IsEmail()
    email: string;
    @ApiProperty()
    @IsNumber()
    teamId: number;
}