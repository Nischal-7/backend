import { Post, Body, Controller, Request, UseGuards, Get, Param, Put, Patch } from "@nestjs/common";
import { User } from "@prisma/client";
import { CreateUserDTO, UpdateUserPasswordDTO, UpdateUserTeamIdDTO } from "./user.dto";
import { UserModule } from "./user.module";
import { UsersService } from "./user.service";
import { ApiTags } from "@nestjs/swagger";

@ApiTags("user")
@Controller("user")
export class UserController {
  constructor(
    private readonly userService: UsersService
  ) {}

  @Post()
  async registerUser(
    @Body()
    userData: CreateUserDTO
  ): Promise<User> {
    return this.userService.createUser(userData);
  }

  @Get()
  async getUsers(): Promise<User[]>{
    return this.userService.getAllUsers();
  }

  @Get(':email')
  async findOne(@Param('email') email:string){
    return this.userService.findOne(email);
  }

  @Put('changePassword')
  async changePassword(@Body() UpdateUserPasswordDTO: UpdateUserPasswordDTO){
    return this.userService.changePassword(UpdateUserPasswordDTO);
  }

  @Patch('updateUserTeamId')
  async updateUserDetails(@Body() UpdateUserTeamIdDTO: UpdateUserTeamIdDTO){
    return this.userService.updateTeamId(UpdateUserTeamIdDTO);
  }
}
