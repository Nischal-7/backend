import { Injectable, NotFoundException } from '@nestjs/common';
import { Prisma, User } from '@prisma/client';
import { PrismaService } from 'src/prisma/prisma.service';
// import * as bcrypt from "bcrypt";
import { hash, compare } from 'bcrypt';
import { CreateUserDTO, UpdateUserPasswordDTO, UpdateUserTeamIdDTO } from './user.dto';

const salt = process.env.salt;

@Injectable()
export class UsersService {
  
  constructor(public prisma: PrismaService) {}

  async findOne(username: string): Promise<User | undefined> {
    let existingUser;
    try{
      existingUser = this.prisma.user.findFirst({
      where: { email: username},
    });
    }
    catch(e){
      return e
    }
    return existingUser;
  }

  async getAllUsers(): Promise<User[]> {
    return this.prisma.user.findMany() 
  }

  async createUser(data: CreateUserDTO): Promise<User> {

    const hashedPassword = await hash(data.password, 10);
    data.password = hashedPassword;
    return this.prisma.user.create({ data });
  }

  async changePassword(data: UpdateUserPasswordDTO): Promise<User> {

    const existingUser = this.prisma.user.findFirst({
      where: { email: data.email},
    });
    if(!existingUser){
      throw new NotFoundException("User not found with the given email-id")
    }
    
    const oldPasswordMatch = await compare(data.oldPassword, (await existingUser).password);

    if(!oldPasswordMatch){
      throw new NotFoundException("Old password does not match");
    }
    const newHashedPassword = await hash(data.newPassword, 10);

    return this.prisma.user.update({where: { email: (await existingUser).email }, data: { password: newHashedPassword}})
  }


  async updateTeamId(data: UpdateUserTeamIdDTO): Promise<User>{
    const existingUser = this.prisma.user.findFirst({
      where: { email: data.email},
    });
    if(!existingUser){
      throw new NotFoundException("User not found with the given email-id")
    }
    if(!data.teamId){
      throw new NotFoundException("TeamId not specified")
    }
    return this.prisma.user.update({where: { email: (await existingUser).email}, data: { teamId: data.teamId }})
  }

}
