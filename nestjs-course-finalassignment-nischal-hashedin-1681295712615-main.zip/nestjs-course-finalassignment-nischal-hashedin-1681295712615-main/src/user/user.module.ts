import { Module } from "@nestjs/common";
import { UsersService } from "./user.service";
import { PrismaService } from "../prisma/prisma.service";
import { UserController } from "./user.controller";
import { JwtService } from "@nestjs/jwt";

@Module({
  providers: [UsersService, PrismaService, JwtService],
  exports: [UsersService],
  controllers: [UserController],
})
export class UserModule {}
