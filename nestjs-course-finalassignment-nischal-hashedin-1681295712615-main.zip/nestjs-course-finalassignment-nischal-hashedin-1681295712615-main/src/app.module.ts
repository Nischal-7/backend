import { MiddlewareConsumer, Module, NestModule } from "@nestjs/common";
import { AppController } from "./app.controller";
import { AppService } from "./app.service";
import { UserModule } from "./user/user.module";
import { TeamModule } from "./team/team.module";
import { ConfigModule } from "@nestjs/config";
import { ProjectModule } from "./project/project.module";
import { EpicModule } from "./epic/epic.module";
import { IssueModule } from "./issue/issue.module";
import { TypeModule } from "./type/type.module";
import { PriorityModule } from "./priority/priority.module";
import { StatusModule } from "./status/status.module";
import { AuthModule } from "./auth/auth.module";
import { PassportModule } from "@nestjs/passport";
import { AuditLogsService } from "./audit/audit.service";
import { AuditMiddleware } from "./audit/apiHistory.middleware";
import { JWTStrategy } from "./auth/jwt.strategy";
import { AuditLogModule } from "./audit/audit.module";
import { PrismaService } from "./prisma/prisma.service";

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    UserModule,
    TeamModule,
    ProjectModule,
    EpicModule,
    IssueModule,
    TypeModule,
    PriorityModule,
    StatusModule,
    AuthModule,
    PassportModule,
    AuditLogModule
  ],

  controllers: [AppController],
  providers: [AppService, JWTStrategy, AuditLogsService,PrismaService ],
})
export class AppModule implements NestModule {
  constructor(private readonly auditLogsService: AuditLogsService) {}

  configure(consumer: MiddlewareConsumer) {
    consumer.apply(AuditMiddleware).forRoutes("*");
  }
}

