import { Injectable } from "@nestjs/common";
import { Status } from "@prisma/client";
import { PrismaService } from "src/prisma/prisma.service";

@Injectable()
export class StatusService{
    constructor( private prisma: PrismaService){}
    async fetchAllStatus():Promise<Status[]>{
        return await this.prisma.status.findMany();
    }
}