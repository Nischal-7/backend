import { Controller, Get } from "@nestjs/common";
import { ApiTags } from "@nestjs/swagger";
import { StatusService } from "./status.service";
import { Status } from "@prisma/client";

@ApiTags("Status")
@Controller("status")
export class StatusController{
    constructor(private readonly statusService: StatusService){}
    @Get()
    async fetchAllStatus(): Promise<Status[]>{
        return await this.statusService.fetchAllStatus();
    }
}