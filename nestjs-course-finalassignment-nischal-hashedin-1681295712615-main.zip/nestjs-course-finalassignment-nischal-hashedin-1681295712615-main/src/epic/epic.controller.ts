import { Body, Controller, Delete, Get, NotFoundException, Param, Patch, Post } from "@nestjs/common";
import { ApiTags } from "@nestjs/swagger";
import { Epic } from "@prisma/client";
import { CreateEpicDTO, UpdateEpicDTO } from "./epic.dto";
import { EpicService } from "./epic.service";

@ApiTags("epic")
@Controller("epic")

export class EpicController{
    constructor (private readonly epicService: EpicService){}

    @Post()
    async createdEpic(
        @Body()
        epic: CreateEpicDTO
    ): Promise<Epic>{
        return this.epicService.createEpic(epic)
    }

    @Get(":id")
    async findOne(@Param("id") id: string):Promise<Epic>{
        const parsedId = parseInt(id, 10);
        const uniqueEpic = await this.epicService.findOneEpic(parsedId);
        if(!uniqueEpic){
            throw new NotFoundException("Epic not found");
        }
        return uniqueEpic;
    }

    @Get("project/:projectId")
    async findByProject(@Param("projectId") projectId: string):Promise<Epic[]>{
        return this.epicService.findByProjectId(+projectId)
    }

    @Get()
    async fetchAllEpics(): Promise<Epic[]>{
        return this.epicService.fetchAllEpics();
    }

    @Patch(":id")
    async updateEpic(
        @Param("id") id:string,
        @Body() data: UpdateEpicDTO
    ):Promise<Epic>{
        const numId = Number(id)
        return this.epicService.updateEpic(numId, data);
    }

    @Delete(":id")
    async deleteEpic(
        @Param("id")id: number
    ){
        return this.epicService.deleteEpic(+id);
    }
}