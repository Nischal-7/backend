import { ApiProperty } from "@nestjs/swagger";
import { IsDate, IsNotEmpty, IsNumber } from "class-validator";

export class CreateEpicDTO{
    @ApiProperty()
    @IsNotEmpty()
    title: string;
    @ApiProperty()
    @IsNumber()
    statusID: number;
    @ApiProperty()
    @IsNotEmpty()
    description: string;
    @ApiProperty()

    start_date: Date;
    @ApiProperty()

    end_date: Date;
    @ApiProperty()

    created_on: Date;
    @ApiProperty()

    updated_on: Date;
    @ApiProperty()
    @IsNumber()
    projectId: number;
}

export class UpdateEpicDTO{
    @ApiProperty()
    title?: string;
    @ApiProperty()
    statusID?: number;
    @ApiProperty()
    description?: string;
    @ApiProperty()
    start_date?: Date;
    @ApiProperty()
    end_date?: Date;
    @ApiProperty()
    created_on?: Date;
    @ApiProperty()
    updated_on?: Date;
    @ApiProperty()
    // @IsNumber()
    projectedId?: number;
}