import { Injectable } from "@nestjs/common";
import { Epic, Prisma } from "@prisma/client";
import { PrismaService } from "src/prisma/prisma.service";
import { updateProjectDTO } from "src/project/project.dto";

@Injectable()
export class EpicService{
    constructor(private prisma: PrismaService){}

    async createEpic(data: Prisma.EpicCreateManyInput):Promise<Epic | undefined>{
        return this.prisma.epic.create({ data });
    }

    async findOneEpic(id: number){
        return this.prisma.epic.findUnique({ where: { id: id }});
    }

    async fetchAllEpics():Promise<Epic[]>{
        return this.prisma.epic.findMany();
    }

    async findByProjectId(projectId: number):Promise<Epic[]>{
        return this.prisma.epic.findMany({where: { projectId: projectId}})

    }

    async updateEpic(id: number, updateProjectDTO: updateProjectDTO):Promise<Epic>{
        const epics = await this.prisma.epic.update({
            where: { id },
            data: updateProjectDTO
        });
        return epics;
    }
    async deleteEpic(id: number){
        const delEpic = await this.prisma.epic.delete({ where: {id: id}});
    }
}