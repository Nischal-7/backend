import { Module } from "@nestjs/common";
import { JwtService } from "@nestjs/jwt";
import { PrismaService } from "src/prisma/prisma.service";
import { EpicService } from "./epic.service";
import { EpicController } from "./epic.controller";

@Module({
    exports: [EpicService],
    controllers: [EpicController],
    providers: [EpicService, PrismaService, JwtService]
})
export class EpicModule{}