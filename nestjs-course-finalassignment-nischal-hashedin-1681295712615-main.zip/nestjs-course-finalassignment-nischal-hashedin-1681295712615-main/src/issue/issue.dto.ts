import { ApiProperty } from "@nestjs/swagger";
import { IsDate, IsNotEmpty, IsNumber } from "class-validator";

export class CreateIssueDTO{
    @ApiProperty()
    @IsNotEmpty()
    title: string;
    @ApiProperty()
    @IsNotEmpty()
    description: string;
    @ApiProperty()
    @IsNumber()
    assigneeId: number;
    @ApiProperty()
    @IsNumber()
    reporterId: number;
    @ApiProperty()
    @IsNumber()
    typeId: number;
    @ApiProperty()
    @IsNumber()
    statusId: number;
    @ApiProperty()
    @IsNumber()
    priorityId: number;
    @ApiProperty()

    start_date: Date;
    @ApiProperty()

    end_date: Date;
    @ApiProperty()
    @IsNumber()
    epicId: number;
}

export class updateIssueDTO{
    @ApiProperty()
    title?: string;
    @ApiProperty()
    description?: string;
    @ApiProperty()
    assigneeId?: number;
    @ApiProperty()
    reporterId?: number;
    @ApiProperty()
    typeId?: number;
    @ApiProperty()
    statusId?: number;
    @ApiProperty()
    priorityId?: number;
    @ApiProperty()
    start_date?: Date;
    @ApiProperty()
    end_date?: Date;
    @ApiProperty()
    epicId?: number;
}

export class filterIssuesDTO{
    @ApiProperty()
    title?: string;
    @ApiProperty()
    description?: string;
    @ApiProperty()
    assigneeId?: number;
    @ApiProperty()
    reporterId?: number;
    @ApiProperty()
    typeId?: number;
    @ApiProperty()
    statusId?: number;
    @ApiProperty()
    priorityId?: number;
    @ApiProperty()
    start_date?: Date;
    @ApiProperty()
    end_date?: Date;
    @ApiProperty()
    epicId?: number;
}