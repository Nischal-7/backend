import { Module } from "@nestjs/common";
import { JwtService } from "@nestjs/jwt";
import { PrismaService } from "src/prisma/prisma.service";
import { IssueController } from "./issue.controller";
import { IssueService } from "./issue.service";

@Module({
    providers: [IssueService, PrismaService, JwtService],
    exports: [IssueService],
    controllers: [IssueController],
})

export class IssueModule{}