import { Body, Controller, Delete, Get, NotFoundException, Param, Patch, Post } from "@nestjs/common";
import { ApiTags } from "@nestjs/swagger";
import { CreateIssueDTO, filterIssuesDTO, updateIssueDTO } from "./issue.dto";
import { Issue, Prisma } from "@prisma/client";
import { IssueService } from "./issue.service";

@ApiTags("issues")
@Controller("issues")

export class IssueController{
    constructor(private readonly issueService: IssueService){}

    @Post("create")
    async addIssue(@Body() issue: CreateIssueDTO): Promise<Issue>{
        return this.issueService.addIssue(issue);
    }

    @Get("issue/:id")
    async findOne(@Param("id") id: number): Promise<Issue>{
        const issue = await this.issueService.findOneIssue(id);
        
        if(!issue){
            throw new NotFoundException("Issue not found");
        }

        return issue;
    }

    @Get("allIssue")
    async fetchAllIssues(): Promise<Issue[]>{
        return this.issueService.fetchAllIssues();
    }

    // @Get("project/:projectId")


    @Patch(":id")
    async updateIssue(@Param("id") id: number, @Body() data: updateIssueDTO):Promise<Issue>{
        return this.issueService.updateIssue(id, data);
    }

    @Delete(":id")
    async deleteIssue(@Param("id") id: number){
        return this.issueService.deleteIssue(id);
    }

    @Post('filter')
    async filterIssues(@Body() data: filterIssuesDTO){
        const issues = await this.issueService.filterIssues(data)
        return issues;
    }
    @Get("projectId/:projectId")
    async findIssuesByProjectId(@Param("projectId") projectId: number){
        return this.issueService.findIssueByProjectId(+projectId);
    }

}