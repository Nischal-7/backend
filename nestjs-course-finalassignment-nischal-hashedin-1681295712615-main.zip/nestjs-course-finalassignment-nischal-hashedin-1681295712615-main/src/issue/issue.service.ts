import { BadRequestException, Injectable, NotFoundException } from "@nestjs/common";
import { Issue, Prisma} from "@prisma/client";
import { PrismaService } from "src/prisma/prisma.service";
import { filterIssuesDTO, updateIssueDTO } from "./issue.dto";

@Injectable()
export class IssueService{
    constructor(public prisma: PrismaService){}

    async addIssue(data: Prisma.IssueCreateManyInput):Promise<Issue>{
        return this.prisma.issue.create({ data });
    }

    async findOneIssue(id: number): Promise<Issue>{
        const numId = Number(id);
        if(isNaN(numId)){
            throw new BadRequestException("Invalid issue id. Issue id must be a number.")
        }
        const issue = await this.prisma.issue.findUnique({ where: { id: numId }});
        if(!issue){
            throw new NotFoundException("Issue not found");
        }
        return issue;
    }

    async fetchAllIssues(): Promise<Issue[]>{
        return this.prisma.issue.findMany();
    }

    async updateIssue(id: number, IssDTO: updateIssueDTO):Promise<Issue>{
        const numId = Number(id);
        const _issue = await this.prisma.issue.update({ where: { id: numId }, data: IssDTO});

        return _issue;
    }

    async deleteIssue(id: number){
        const numId = Number(id);
        const delIssue = await this.prisma.issue.delete({ where: {id: numId}});
    }

    async filterIssues(data: filterIssuesDTO): Promise<Issue[]>{
        const issues = await this.prisma.issue.findMany({
            where:{
                title: data.title,
                description: data.description,
                assigneeId: data.assigneeId,
                reporterId: data.reporterId,
                typeId: data.typeId,
                statusId: data.statusId,
                priorityId: data.priorityId,
                start_date: data.start_date,
                end_date: data.end_date,
                epicId: data.epicId
            }
        });
        return issues;
    }

    async findIssueByProjectId(projectId: number):Promise<Issue[]>{
        return this.prisma.issue.findMany({ where:{ epic:{ project: { id: projectId } } } });
    }
    
}