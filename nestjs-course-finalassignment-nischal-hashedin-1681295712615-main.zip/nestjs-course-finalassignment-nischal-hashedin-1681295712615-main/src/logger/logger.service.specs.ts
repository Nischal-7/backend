import { Test, TestingModule } from "@nestjs/testing";
import { LoggerService } from "./logger.service"

describe('LoggerService', ()=>{
    let loggerService: LoggerService;

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers: [LoggerService]
        }).compile();
    })

    it('Must be defined', () => {
        expect(loggerService).toBeDefined();
    });
});