import { Injectable } from "@nestjs/common";
import { ConfigService } from "@nestjs/config";
import { Logger, createLogger, format, transports } from 'winston';
@Injectable()
export class LoggerService{
    private logger: Logger; 

    constructor(private config: ConfigService){

        this.logger = createLogger({
            level: this.config.get('Log Level'),
            format: format.combine(
                format.timestamp(),
                format.errors({ stack: true}),
                format.splat(),
                format.json()
            ),
            transports:[
                new transports.Console(),
                new transports.File({
                    filename: 'logs/error.log',
                    level:'silly',
                }),
                new transports.File({
                    filename: 'logs/combined.log'
                })
            ]
        })
    }

    log(logMessage: string, logContext?: string): void{
        this.logger.log('info', logMessage, {logContext});
    }

    error(logMessage: string, logTrace?: string, logContext?: string): void{
        this.logger.log('error', logMessage, {logTrace, logContext});
    }
    
}