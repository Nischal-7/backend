import {
  Body,
  Controller,
  Get,
  NotFoundException,
  Param,
  Post,
  UseGuards,
} from "@nestjs/common";
import { Team } from "@prisma/client";
import { TeamService } from "./team.service";
import { TeamModule } from "src/team/team.module";
import { ApiTags } from "@nestjs/swagger";
import { TeamDto, UpdateTeamId } from "./team.dto";

@ApiTags("teams")
@Controller("teams")
export class TeamController {
  constructor(private teamService: TeamService) {}

  @Post()
  async createTeam(@Body()team: TeamDto): Promise<Team> {
    return this.teamService.createTeam(team);
  }

  @Get(":id")
  async findOne(@Param("id") id: string) {
    const team = await this.teamService.findOneTeam(+id);

    if (!team) {
      throw new NotFoundException("Team not found");
    }

    return team;
  }

  @Get()
  async getAllTeams(): Promise<Team[]> {
    return this.teamService.getAllTeams();
  }

  @Post("addUsers")
  async addUsers(@Body() data: UpdateTeamId): Promise<Team>{
    return this.teamService.addUsers(data);
  }
}
