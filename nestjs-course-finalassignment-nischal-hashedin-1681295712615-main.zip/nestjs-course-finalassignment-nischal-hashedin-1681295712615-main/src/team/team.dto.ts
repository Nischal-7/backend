import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsString } from 'class-validator';

export class TeamDto {
  @ApiProperty({ description: 'please enter your name' })
  @IsString()
  name: string;

  @ApiProperty({ description: 'please enter list of users' })
  @IsInt()
  projectId: number;
}

export class UpdateTeamId{
  @ApiProperty({description: 'please enterlist of users'})
  @IsInt()
  teamId: number;
  @ApiProperty()
  users: number[];
}