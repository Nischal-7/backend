import { Injectable, NotFoundException } from "@nestjs/common";
import { Team, Prisma } from "@prisma/client";
import { PrismaService } from "src/prisma/prisma.service";
import { UpdateTeamId } from "./team.dto";

@Injectable()
export class TeamService {
  constructor(private prisma: PrismaService) {}

  async createTeam(data: Prisma.TeamCreateManyInput): Promise<Team | undefined> {
    return this.prisma.team.create({ data });
  }

  async findOneTeam(id: number) {
    return this.prisma.team.findUnique({
      where: { id },
      // include: { users: true, projects: true },
    });
  }

  async getAllTeams(): Promise<Team[]> {
    return this.prisma.team.findMany();
  }

  async addUsers(data: UpdateTeamId): Promise<Team>{
    let updatedUser;

   for(let i=0; i<data.users.length; i++){
      const existingUser = this.prisma.user.findFirst({
        where: { id: data.users[i]}
      });
      if(!existingUser){
        throw new NotFoundException(`User with user id ${data.users[i]} does not exist in the user table`);
      }

      updatedUser = await this.prisma.user.update({where:{id:data.users[i]}, data: { teamId: data.teamId}});
   }
   return updatedUser;
  }
}