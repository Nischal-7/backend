import { Injectable, NestMiddleware } from "@nestjs/common";
import { ApiBearerAuth } from "@nestjs/swagger";

import { Audit } from "@prisma/client";
import { PrismaService } from "src/prisma/prisma.service";
import { Request, Response } from "express";
import { JwtService } from "@nestjs/jwt";
@Injectable()
@ApiBearerAuth()
export class AuditLogsService {
  constructor(private prisma: PrismaService, private jwtService: JwtService) {}

  async filterData(data, req: any, res: any) {
    try {
      const selected_filtered_data = await this.prisma.audit.findMany({
        where: data,
      });
      return res.status(200).send({
        message: "Sucess",
        res: selected_filtered_data,
      });
    } catch (e) {
      return res.status(400).send({
        message: "Error Occured",
        response: e,
      });
    }
  }

  async getAllData(req: Request, res: Response) {
    try {
      const getAll = await this.prisma.audit.findMany();
      if (getAll) {
        return res.status(200).send({ getAll });
      } else {
        return res.status(201).send({
          message: "Sucess",
          response: "No data found",
        });
      }
    } catch (e) {
      return res.status(404).send({
        message: "Error Occured",
        error: e,
      });
    }
  }

  async createAuditLog(
    method: string,
    actionTable: string,
    auditUser: string,
    statusCode: number,
    changes?: string | null,
    timeStamp?: Date,
    req?: Request,
    res?: Response
  ): Promise<Audit> {
    const user_name = await this.getUserDetails(req, res);
    // console.log(req.body.email)
    return this.prisma.audit.create({
      data: {
        method,
        actionTable,
        auditUser: user_name,
        statusCode,
        changes,
        timeStamp,
      },
    });
  }

  async getUserDetails(req: Request, res: Response) {
    let _token = "";
    const lets_for_token = req.get("cookie");
    if (lets_for_token) {
      const _for_token = lets_for_token.split(";");
      _for_token.forEach((__token) => {
        if (__token[0] == "token" || __token.substring(1, 6) == "token") {
          _token = __token.substring(7);
        } else {
          _token = "";
        }
      });
      if (_token.length == 0) {
        return "";
      } else {
        const user = await this.jwtService.decode(_token); //to get the information of user from the jwt string
        return user["username"];
      }
    } else {
      return "User Not Logged in";
    }
  }
}
