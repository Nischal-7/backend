import { Controller, Post, Body, Get, Req, Res } from "@nestjs/common";
import { AuditLogsService } from "./audit.service";
import { ApiBody, ApiTags } from "@nestjs/swagger";

@ApiTags("Audit")
@Controller("audit")
export class AuditLogsController {
  constructor(private auditLogsService: AuditLogsService) {}

  @Get()
  getall(@Req() req, @Res() res) {
    return this.auditLogsService.getAllData(req, res);
  }

  @Post("filter")
  @ApiBody({
    schema: {
      type: "object",
      properties: {
        method: { type: "string" },
        changes: { type: "number" },
        actionTable: { type: "string" },
        start_date: { type: "string", format: "date-time" },
        end_date: { type: "string", format: "date-time" },
        auditUser: { type: "string" },
        entityId: { type: "number" },
        statusCode: { type: "number" },
      },
    },
  })
  filterBasedOnData(@Body() _data, @Req() req, @Res() res) {
    return this.auditLogsService.filterData(_data, req, res);
  }
}
