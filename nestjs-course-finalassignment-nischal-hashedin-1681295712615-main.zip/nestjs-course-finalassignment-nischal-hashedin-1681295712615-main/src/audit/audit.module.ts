import { Module } from "@nestjs/common";
import { ConfigModule } from "@nestjs/config";
import { JwtModule } from "@nestjs/jwt";
import { PrismaModule } from "src/prisma/prisma.module";
import { AuditLogsController } from "./audit.controller";
import { AuditLogsService } from "./audit.service";
import { JWTStrategy } from "src/auth/jwt.strategy";
import { AuthService } from "src/auth/auth.service";

@Module({
  imports: [JwtModule, PrismaModule],

  controllers: [AuditLogsController],
  providers: [AuditLogsService, JWTStrategy,AuthService],
})
export class AuditLogModule {}
