import { ApiProperty } from "@nestjs/swagger";
import { IsString } from "class-validator";

export class loginUserDTO {
    @ApiProperty({
        required: true,
        description: "Enter your email",
        example: "abc@gmail.com"
    })
    @IsString()
    email: string

    @ApiProperty({
        required: true,
        description: "Enter your password",
        example: "1234"
    })
    @IsString()
    password: string
}

export interface JwtPayload {
    email: string;
    userId: number;
    role: string;
}

export class PostAuthDTO {
    id: number;
    first_name: string;
    last_name: string;
    role: string;
    email: string;
}

