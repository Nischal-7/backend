import { Module } from "@nestjs/common";
import { JwtModule } from "@nestjs/jwt";
import { PassportModule } from "@nestjs/passport";
import { PrismaService } from "src/prisma/prisma.service";
import { AuthService } from "./auth.service";
import { JWTStrategy } from "./jwt.strategy";
// import { AuditService } from "src/audit/audit.service";
import { AuthController } from "./auth.controller";
import { AuditLogsService } from "src/audit/audit.service";
import { AuditLogsController } from "src/audit/audit.controller";

@Module({
    imports: [
        JwtModule.register({
            secret: process.env.JWT_SECRET,
            signOptions: {
                expiresIn: '36000s'
            },
            global: true
        }),
        PassportModule.register({
            defaultStrategy: 'jwt'
        })
    ],
    providers: [AuthService, PrismaService, JWTStrategy, AuditLogsService],
    controllers: [AuthController, AuditLogsController],
    exports: [AuthService, JWTStrategy, PassportModule, AuditLogsService]
})
export class AuthModule { }
