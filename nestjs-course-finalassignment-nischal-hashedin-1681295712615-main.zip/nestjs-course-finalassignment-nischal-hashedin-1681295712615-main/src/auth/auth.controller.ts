import { Body, Controller, Post, Req } from "@nestjs/common";
import { AuthService } from "./auth.service";
// import { AuditService } from "src/audit/audit.service";
import { ApiBody } from "@nestjs/swagger";
import { loginUserDTO } from "./auth.dto";
// import { SkipThrottle, Throttle } from "src/audit/audit.service"

@Controller()
export class AuthController {

    constructor(
        private readonly authService: AuthService,
        // private readonly auditService: AuditService
    ) { }

    @Post('/login')
    @ApiBody({ type: loginUserDTO })
    // @Throttle(5, 10)
    async login(
        @Req() req: Request,
        @Body() authCredential: loginUserDTO
    ): Promise<{ access_token: string }> {
        return this.authService.login(authCredential)
    }
}