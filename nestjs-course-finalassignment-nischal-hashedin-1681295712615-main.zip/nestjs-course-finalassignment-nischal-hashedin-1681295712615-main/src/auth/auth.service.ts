import { Inject, Injectable, UnauthorizedException, forwardRef } from "@nestjs/common";
import { PrismaService } from "src/prisma/prisma.service";
import { JwtPayload, loginUserDTO } from "./auth.dto";
import { JwtService } from "@nestjs/jwt";
import * as bcrypt from 'bcrypt'
import { AuditLogsService } from "src/audit/audit.service";

@Injectable()
export class AuthService {

    constructor(
        private readonly jwtService: JwtService,
        private readonly prisma: PrismaService,
        // @Inject(forwardRef(() => AuditLogsService))
        private readonly auditService: AuditLogsService
    ) { }

    async login(
        authCredential: loginUserDTO
    ): Promise<{ access_token: string }> {
        const { email, password } = authCredential;
        const user = await this.prisma.user.findUnique({
            where: {
                email
            }
        });

        if (!user)
            throw new UnauthorizedException(`Email ${email} not registered`)

        if (await bcrypt.compare(password, user.password)) {
            const payload: JwtPayload = {
                email,
                userId: user.id,
                role: user.role
            };
            const access_token: string = await this.jwtService.sign(payload, {
                secret: process.env.JWT_SECRET
            })
            return {
                access_token
            };
        }
        else
            throw new UnauthorizedException('Incorrect Password')
    }
}

