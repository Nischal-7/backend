import { Body, Controller, Delete, Get, Param, Patch, Post } from "@nestjs/common";
import { ApiTags } from "@nestjs/swagger";
import { ProjectService } from "./project.service";
import { CreateProjectDTO, updateProjectDTO } from "./project.dto";
import { Project } from "@prisma/client";

@ApiTags('project')
@Controller('project')
export class ProjectController{
    constructor(private readonly projectService: ProjectService){}

    @Post()
    async addProject( @Body() newProject: CreateProjectDTO): Promise<Project>{
        const proj = this.projectService.addProject(newProject);
        return proj;
    }

    @Get(':id')
    async findSingleProject(@Param("id") id: string):Promise<Project>{
        let proj: Project;
        try{
            proj = await this.projectService.findSingleProject(+id);
        }
        catch(e){
            return e;
        }
        return proj;
    }

    @Get()
    async fetchAllProjects(): Promise<Project[]>{
        return this.projectService.fetchAllProjects();
    }

    @Patch(":id")
    async updateProject(@Param("id")id: number, @Body() data: updateProjectDTO):Promise<Project>{
        return this.projectService.updateProject(id, data);
    }

    @Delete(":id")
    async deleteProject(
        @Param("id") id: number
    ){
        return this.projectService.deleteProject(id);
    }
}