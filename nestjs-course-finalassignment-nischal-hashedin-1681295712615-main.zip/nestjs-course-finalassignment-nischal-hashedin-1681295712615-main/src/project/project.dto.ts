import { ApiProperty } from "@nestjs/swagger";
import { IsDate, IsNotEmpty, IsNumber } from "class-validator";

export class CreateProjectDTO{
    @ApiProperty()
    @IsNotEmpty()
    title: string;
    @ApiProperty()
    @IsNotEmpty()
    description: string;
    @ApiProperty()
    start_date: Date;
    @ApiProperty()
    end_date: Date;

    ownerId?: number;
    @ApiProperty()
    @IsNumber()
    teamId: number;
}

export class updateProjectDTO{
    @ApiProperty()
    title?: string;
    @ApiProperty()
    description?: string;
    @ApiProperty()
    start_date?: Date;
    @ApiProperty()
    end_date?: Date;
    @ApiProperty()
    ownerId?: number;
}