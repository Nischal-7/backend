import { Injectable } from "@nestjs/common";
import { Prisma, Project } from "@prisma/client";
import { PrismaService } from "src/prisma/prisma.service";
import { updateProjectDTO } from "./project.dto";

@Injectable()
export class ProjectService{
    constructor(private prisma: PrismaService){}

    async addProject(data: Prisma.ProjectCreateManyInput): Promise<Project>{
        return this.prisma.project.create({ data });
    };

    async findSingleProject(id: number): Promise<Project>{
        return this.prisma.project.findUnique({
            where: {id: id}
        });
    }

    async fetchAllProjects(): Promise<Project[]>{
        return this.prisma.project.findMany();
    }

    async updateProject(id: number, updateProjectDTO: updateProjectDTO): Promise<Project>{
        try{
            const proj = await this.prisma.project.findUnique({
            where: {id: Number(id)}
        });
        }
        catch(e){
            return e;
        }

        const project = await this.prisma.project.update({
            where: { id: Number(id)},
            data: updateProjectDTO
        });
        return project;
    }

    async deleteProject(id: number){
        const dProj = await this.prisma.project.delete({
            where: { id: Number(id)}
        });
    }
}