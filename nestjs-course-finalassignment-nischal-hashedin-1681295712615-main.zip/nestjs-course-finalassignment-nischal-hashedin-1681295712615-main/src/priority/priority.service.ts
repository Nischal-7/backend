import { Injectable } from "@nestjs/common";
import { Priority } from "@prisma/client";
import { PrismaService } from "src/prisma/prisma.service";

@Injectable()
export class PriorityService{
    constructor( private prisma: PrismaService){}
    async fetchAllPriorities():Promise<Priority[]>{
        return await this.prisma.priority.findMany();
    }
}