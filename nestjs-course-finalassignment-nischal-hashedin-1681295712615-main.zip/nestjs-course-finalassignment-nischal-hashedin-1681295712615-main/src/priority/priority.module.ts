import { Module } from "@nestjs/common";
import { PriorityController } from "./priority.controller";
import { PriorityService } from "./priority.service";
import { PrismaService } from "src/prisma/prisma.service";

@Module({
    controllers: [PriorityController],
    providers: [PriorityService, PrismaService]
})
export class PriorityModule{}